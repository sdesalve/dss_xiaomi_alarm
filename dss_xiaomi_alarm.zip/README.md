# dss_xiaomi_alarm
Allarme Xiaomi by SDeSalve

Guida ed informazioni: https://hassiohelp.eu/2019/06/11/xiaomi-alarm/



## Ciao amico! ##

Se trovi utile questo lavoro e vuoi ringraziarmi, puoi offrirmi uno o più caffè! 

I :hearts: so much coffee... :grimacing::grimacing::grimacing:

Grazie per il tuo supporto!

[![Buy me a coffee][buymeacoffee-shield]][buymeacoffee] [![Support my work on Paypal][paypal-shield]][paypal]

[buymeacoffee-shield]: https://www.buymeacoffee.com/assets/img/guidelines/download-assets-sm-2.svg
[buymeacoffee]: https://www.buymeacoffee.com/sdesalve
[paypal-shield]: https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif
[paypal]: https://paypal.me/SDeSalve
